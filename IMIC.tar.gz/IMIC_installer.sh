#!/bin/sh
# This file is used to create the IMIC data collection environment
# October 2018 - PNNL
# 

mkdir IMIC
cd IMIC/

wget -q ftp://math.nist.gov/pub/pozo/src/iml.shar
mkdir src/
cd src/
bash ../iml.shar
cd ../
rm iml.shar

wget -q ftp://math.nist.gov/pub/pozo/src/imltest.shar
bash imltest.shar
rm imltest.shar

wget https://math.nist.gov/sparselib++/sparselib_1_7.zip
unzip sparselib_1_7.zip
rm sparselib_1_7.zip
cd SparseLib++/1.7/
make sp
cd ../../

mkdir readRB
cd readRB
cp SparseLib++/1.7/include/iohb.h ./ioRB.h
cp SparseLib++/1.7/src/iohb.c ./ioRB.cc
cd ../

mkdir Datasets
cd Datasets
wget https://sparse.tamu.edu/RB/HB/bcsstk14.tar.gz
tar xzf bcsstk14.tar.gz
rm bcsstk14.tar.gz
cd ../

patch -p1 < ../IMIC_patch.patch
